/********************************************************************************/
/*										*/
/*	Created By: Scott Jolly				 	       		*/	*/
/*	Created: January 24th 2019   						*/
/*	Wedgewood Pacific (WP) Create Data					*/
/*										*/
/*	      							                */
/*										*/
/********************************************************************************/
CREATE TABLE department (
                DepartmentName CHAR(35) NOT NULL,
                BudegetCode CHAR(30) NOT NULL,
                OfficeNumber CHAR(15) NOT NULL,
                DepartmentPhone CHAR(12) NOT NULL,
                PRIMARY KEY (DepartmentName)
);


CREATE TABLE project (
                ProjectID INT NOT NULL,
                ProjectName CHAR(50) NOT NULL,
                Department CHAR(35) NOT NULL,
                MaxHours DOUBLE PRECISION NOT NULL,
                StartDate DATE,
                EndDate DATE,
                PRIMARY KEY (ProjectID)
);


CREATE TABLE employee (
                EmployeeNumber INT AUTO_INCREMENT NOT NULL,
                FirstName CHAR(25) NOT NULL,
                LastName CHAR(25) NOT NULL,
                Department CHAR(35) NOT NULL,
                Position CHAR(35),
                SuperVisor INT,
                OfficePhone CHAR(12),
                EmailAddress VARCHAR(100) NOT NULL,
                Parent_EmployeeNumber INT NOT NULL,
                PRIMARY KEY (EmployeeNumber)
);


CREATE TABLE assignment (
                ProjectID INT NOT NULL,
                EmployeeNumber INT NOT NULL,
                HoursWorked DOUBLE PRECISION,
                PRIMARY KEY (ProjectID, EmployeeNumber)
);


ALTER TABLE employee ADD CONSTRAINT department_employee_fk
FOREIGN KEY (Department)
REFERENCES department (DepartmentName)
ON DELETE NO ACTION
ON UPDATE CASCADE;

ALTER TABLE project ADD CONSTRAINT department_project_fk
FOREIGN KEY (Department)
REFERENCES department (DepartmentName)
ON DELETE NO ACTION
ON UPDATE CASCADE;

ALTER TABLE assignment ADD CONSTRAINT project_assignment_fk
FOREIGN KEY (ProjectID)
REFERENCES project (ProjectID)
ON DELETE CASCADE
ON UPDATE NO ACTION;

ALTER TABLE assignment ADD CONSTRAINT employee_assignment_fk
FOREIGN KEY (EmployeeNumber)
REFERENCES employee (EmployeeNumber)
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE employee ADD CONSTRAINT employee_employee_fk
FOREIGN KEY (SuperVisor)
REFERENCES employee (EmployeeNumber)
ON DELETE NO ACTION
ON UPDATE CASCADE;
